#include "types.h"
#include "user.h"

int
main(void)
{
  clear();
  exit();
}